package philosophers_RMI;

public enum States {
    RETRY, LEFT_ACQUIRED, LEFT_REFUSED, COMPLETE
}
