package philosophers_thread;

public interface Settings {
    public final static int NUM_PHILOSOPHERS = 5;
    public final static int THINKING_TIME = 256;
}
