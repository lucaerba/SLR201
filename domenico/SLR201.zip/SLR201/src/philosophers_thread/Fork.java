package philosophers_thread;


public class Fork {


    /**
     * Philosophers should use this method to eat.
     * It is only a mock method
     */
    public void eat() throws RuntimeException{
        // Do nothing
    }
}
